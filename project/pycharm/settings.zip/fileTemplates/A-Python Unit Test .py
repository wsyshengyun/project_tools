import unittest


class MyTestCase(unittest.TestCase):
    
    def setUp(self) -> None:
        pass
    
    def tearDown(self) -> None:
        pass

    def test_1(self):
        pass

    def test_2(self):
        pass

    def test_3(self):
        pass

    def test_4(self):
        pass

    def test_5(self):
        pass

    def test_6(self):
        pass

    def test_7(self):
        pass

    def test_8(self):
        pass

    def test_9(self):
        pass


if __name__ == '__main__':
    unittest.main()